# Assignment 3 WBS and LoE		
## TOTAL ESTIMATE: 5h 40min     	ACTUAL: (TBD)
## Task 1: Project Preparation			
### LoE (estimated): 1h             LoE (actual):
	1.1 Work Breakdown Structure		15 min
	1.2 Level of Effort estimations		10 min
	1.3 Gantt chart				        15 min
	1.4 ReadMe.md				        10 min
	1.5 GitHub Repository set		    10 min
--------------------------------------------------------
## Task 2: Data Storing Wrapper			
### LoE (estimated): 30 min         LoE (actual):
	2.1: Create implementation		    10 min
	2.2: Delete implementation		    10 min
	2.3: Update implementation		    10 min
--------------------------------------------------------
## Task 3: Initial UI implementation
### LoE (estimated): 40 min         LoE (actual):
	2.4: Setting Routes			        20 min
	2.5: Creating a Shared Layout		20 min	
--------------------------------------------------------
## Task 4: Content Creation Screen
### LoE (estimated): 1h 20min       LoE (actual):
	3.1: Screen Layout			        20 min	
	3.2: Content creation form		    1h
--------------------------------------------------------
## Task 5: Content Listing Screen
### LoE (estimated): 1h 5min        LoE (actual):
	4.1: Screen Layout			        20 min
	4.2: Content List display		    45 min
--------------------------------------------------------
## Task 6: Content Details Screen
### LoE (estimated): 1h 5min        LoE (actual):
	5.1: Screen Layout			        20 min
	5.2: Content Details card		    45 min